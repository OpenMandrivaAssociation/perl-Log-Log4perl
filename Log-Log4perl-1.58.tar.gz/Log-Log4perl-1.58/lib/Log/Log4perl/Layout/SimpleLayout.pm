##################################################
package Log::Log4perl::Layout::SimpleLayout;
##################################################
# as documented in
# http://jakarta.apache.org/log4j/docs/api/org/apache/log4j/SimpleLayout.html
##################################################

use 5.006;
use strict;
use warnings;
use Log::Log4perl::Level;

no strict qw(refs);
use base qw(Log::Log4perl::Layout);

##################################################
sub new {
##################################################
    my $class = shift;
    $class = ref ($class) || $class;

    my $self = {
        format      => undef,
        info_needed => {},
        stack       => [],
    };

    bless $self, $class;

    return $self;
}

##################################################
sub render {
##################################################
    my($self, $message, $category, $priority, $caller_level) = @_;

    return "$priority - $message\n";
}

1;

__END__

=encoding utf8

=head1 NAME

Log::Log4perl::Layout::SimpleLayout - Simple Layout

=head1 SYNOPSIS

  use Log::Log4perl::Layout::SimpleLayout;
  my $layout = Log::Log4perl::Layout::SimpleLayout->new();

=head1 DESCRIPTION

This class implements the C<log4j> simple layout format -- it basically 
just prints the message priority and the message, that's all.
Check 
http://jakarta.apache.org/log4j/docs/api/org/apache/log4j/SimpleLayout.html
for details.

=head1 SEE ALSO

=head1 LICENSE

Copyright 2002-2026 by Mike Schilli E<lt>m@perlmeister.comE<gt>
and Kevin Goess E<lt>cpan@goess.orgE<gt>.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
